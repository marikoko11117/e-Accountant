import React, { useState, useEffect } from 'react';
import { Outlet } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { Topbar } from './Topbar';
import { MobileNav } from './MobileNav';
import { ComplianceFooter } from '../compliance/ComplianceFooter';

export const Shell: React.FC = () => {
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(() => {
    return localStorage.getItem('e_accountant_sidebar_collapsed') === 'true';
  });

  // Observe sidebar collapse state in localStorage
  useEffect(() => {
    const handleStorage = () => {
      setIsSidebarCollapsed(localStorage.getItem('e_accountant_sidebar_collapsed') === 'true');
    };
    window.addEventListener('storage', handleStorage);
    // Also poll on click/mutation
    const interval = setInterval(handleStorage, 300);
    return () => {
      window.removeEventListener('storage', handleStorage);
      clearInterval(interval);
    };
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col">
      {/* Desktop Sidebar */}
      <div className="hidden md:block">
        <Sidebar />
      </div>

      {/* Mobile Drawer */}
      <MobileNav isOpen={mobileNavOpen} onClose={() => setMobileNavOpen(false)} />

      {/* Main Content Area */}
      <div
        className={`flex-1 flex flex-col transition-all duration-300 ${
          isSidebarCollapsed ? 'md:ml-20' : 'md:ml-64'
        }`}
      >
        <Topbar onToggleMobileNav={() => setMobileNavOpen(true)} />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto flex flex-col justify-between">
          <Outlet />
          <ComplianceFooter />
        </main>
      </div>
    </div>
  );
};
