import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  BookOpen,
  FolderTree,
  Scale,
  FileSpreadsheet,
  Settings,
  ChevronLeft,
  ChevronRight,
  Calculator,
  ShieldCheck,
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { useAuth } from '../../context/AuthContext';

export const Sidebar: React.FC = () => {
  const { t } = useLanguage();
  const { isDemo } = useAuth();
  const [collapsed, setCollapsed] = useState<boolean>(() => {
    return localStorage.getItem('e_accountant_sidebar_collapsed') === 'true';
  });

  useEffect(() => {
    localStorage.setItem('e_accountant_sidebar_collapsed', String(collapsed));
  }, [collapsed]);

  const navItems = [
    { to: '/dashboard', labelKey: 'nav.dashboard' as const, icon: LayoutDashboard },
    { to: '/journal', labelKey: 'nav.journal' as const, icon: BookOpen },
    { to: '/accounts', labelKey: 'nav.accounts' as const, icon: FolderTree },
    { to: '/ledger', labelKey: 'nav.ledger' as const, icon: Scale },
    { to: '/reports', labelKey: 'nav.reports' as const, icon: FileSpreadsheet },
    { to: '/settings', labelKey: 'nav.settings' as const, icon: Settings },
  ];

  return (
    <aside
      className={`fixed top-0 left-0 z-30 h-screen transition-all duration-300 ease-in-out border-r
        bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 flex flex-col justify-between
        ${collapsed ? 'w-20' : 'w-64'}`}
    >
      {/* Top Header */}
      <div>
        <div className="flex items-center justify-between h-16 px-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center space-x-3 overflow-hidden">
            <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-brand-600 text-white shrink-0 shadow-sm shadow-brand-500/20">
              <Calculator className="w-5 h-5" />
            </div>
            {!collapsed && (
              <div className="leading-tight truncate">
                <h1 className="font-bold text-slate-900 dark:text-white text-base tracking-tight truncate">
                  e-Accountant
                </h1>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-medium truncate">
                  For You
                </p>
              </div>
            )}
          </div>

          <button
            onClick={() => setCollapsed(!collapsed)}
            title={collapsed ? t('nav.expand') : t('nav.collapse')}
            className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        {/* Navigation Links */}
        <nav className="p-3 space-y-1.5">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `flex items-center space-x-3 px-3 py-2.5 rounded-xl font-medium text-sm transition-all duration-150 ${
                    isActive
                      ? 'bg-brand-50 dark:bg-brand-950/50 text-brand-700 dark:text-brand-300 shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100/80 dark:hover:bg-slate-800/60'
                  } ${collapsed ? 'justify-center px-2' : ''}`
                }
              >
                <Icon className="w-5 h-5 shrink-0" />
                {!collapsed && <span className="truncate">{t(item.labelKey)}</span>}
              </NavLink>
            );
          })}
        </nav>
      </div>

      {/* Footer Info & Status */}
      <div className="p-3 border-t border-slate-200 dark:border-slate-800">
        {!collapsed && isDemo && (
          <div className="mb-2 p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200/80 dark:border-amber-800/50 text-amber-800 dark:text-amber-200 text-xs">
            <div className="flex items-center space-x-1.5 font-semibold">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Demo Workspace</span>
            </div>
            <p className="mt-0.5 text-[11px] text-amber-700 dark:text-amber-300">
              Local testing enabled
            </p>
          </div>
        )}

        <div className={`flex items-center ${collapsed ? 'justify-center' : 'justify-between px-2'} text-xs text-slate-400`}>
          {!collapsed && <span>v1.0.0</span>}
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" title="System Online" />
        </div>
      </div>
    </aside>
  );
};
