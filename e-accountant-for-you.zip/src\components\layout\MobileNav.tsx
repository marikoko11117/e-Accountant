import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  BookOpen,
  FolderTree,
  Scale,
  FileSpreadsheet,
  Settings,
  X,
  Calculator,
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

interface MobileNavProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({ isOpen, onClose }) => {
  const { t } = useLanguage();

  if (!isOpen) return null;

  const navItems = [
    { to: '/dashboard', labelKey: 'nav.dashboard' as const, icon: LayoutDashboard },
    { to: '/journal', labelKey: 'nav.journal' as const, icon: BookOpen },
    { to: '/accounts', labelKey: 'nav.accounts' as const, icon: FolderTree },
    { to: '/ledger', labelKey: 'nav.ledger' as const, icon: Scale },
    { to: '/reports', labelKey: 'nav.reports' as const, icon: FileSpreadsheet },
    { to: '/settings', labelKey: 'nav.settings' as const, icon: Settings },
  ];

  return (
    <div className="fixed inset-0 z-50 md:hidden flex">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      {/* Drawer */}
      <div className="relative w-72 bg-white dark:bg-slate-900 h-full p-4 flex flex-col justify-between shadow-2xl z-10">
        <div>
          <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
            <div className="flex items-center space-x-3">
              <div className="flex items-center justify-center w-9 h-9 rounded-xl bg-brand-600 text-white">
                <Calculator className="w-5 h-5" />
              </div>
              <span className="font-bold text-slate-900 dark:text-white text-base">
                e-Accountant
              </span>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <nav className="mt-4 space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.to}
                  to={item.to}
                  onClick={onClose}
                  className={({ isActive }) =>
                    `flex items-center space-x-3 px-3 py-2.5 rounded-xl font-medium text-sm transition-colors ${
                      isActive
                        ? 'bg-brand-50 dark:bg-brand-950/50 text-brand-700 dark:text-brand-300'
                        : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`
                  }
                >
                  <Icon className="w-5 h-5 shrink-0" />
                  <span>{t(item.labelKey)}</span>
                </NavLink>
              );
            })}
          </nav>
        </div>

        <div className="text-xs text-slate-400 text-center py-2">
          e-Accountant For You v1.0
        </div>
      </div>
    </div>
  );
};
