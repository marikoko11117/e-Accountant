import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowRight,
  ShieldCheck,
  TrendingUp,
  Receipt,
  Layers,
  Sparkles,
  FolderTree,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { getAccounts } from '../services/accountService';
import { Account } from '../types/account';

export const DashboardPage: React.FC = () => {
  const { user, isDemo } = useAuth();
  const { t } = useLanguage();
  const [accounts, setAccounts] = useState<Account[]>([]);

  useEffect(() => {
    if (!user) return;
    getAccounts(user.uid, isDemo).then(setAccounts).catch(console.error);
  }, [user, isDemo]);

  const activeAccounts = accounts.filter((a) => a.status === 'active');
  const assetCount = accounts.filter((a) => a.type === 'asset').length;
  const liabilityCount = accounts.filter((a) => a.type === 'liability').length;

  const stageFeatures = [
    {
      title: 'Stage 1: Foundation & Auth',
      status: 'completed',
      description: 'Firebase Auth, Protected Routes, Security Rules, and Responsive Navigation Shell.',
      badge: 'Completed',
    },
    {
      title: 'Stage 2: Chart of Accounts',
      status: 'completed',
      description: 'Create & manage Assets, Liabilities, Equity, Income, Expenses with normal balance rules.',
      link: '/accounts',
      badge: `${accounts.length} Accounts Active`,
    },
    {
      title: 'Stage 3: Journal Entries',
      status: 'up-next',
      description: 'Double-entry validator ensuring live Debits == Credits balance before saving.',
      link: '/journal',
      badge: 'Up Next',
    },
    {
      title: 'Stage 4: Ledger & T-Accounts',
      status: 'planned',
      description: 'Dual view: Chronological general ledger and visual T-Accounts with running balances.',
      link: '/ledger',
      badge: 'Stage 4',
    },
    {
      title: 'Stage 5: Financial Reports',
      status: 'planned',
      description: 'Trial Balance, Income Statement (P&L), Balance Sheet, and CSV exports.',
      link: '/reports',
      badge: 'Stage 5',
    },
    {
      title: 'Stage 6: Notion-Style Widgets',
      status: 'planned',
      description: 'Customizable draggable widgets with layout state saved per user in Firestore.',
      badge: 'Stage 6',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand-600 via-brand-700 to-indigo-800 p-6 sm:p-8 text-white shadow-xl shadow-brand-500/10">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur text-xs font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Double-Entry Bookkeeping System</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
            {t('stage1.welcome')}, {user?.displayName || 'Bookkeeper'}
          </h1>
          <p className="mt-2 text-sm text-brand-100 leading-relaxed">
            Manage transactions, structure your chart of accounts, and maintain flawless double-entry balance sheets.
          </p>

          <div className="mt-5 flex flex-wrap items-center gap-3">
            <Link
              to="/accounts"
              className="inline-flex items-center space-x-2 px-4 py-2 rounded-xl bg-white text-brand-700 font-semibold text-xs shadow-md hover:bg-brand-50 transition-colors"
            >
              <FolderTree className="w-3.5 h-3.5" />
              <span>Chart of Accounts ({accounts.length})</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
            <div className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-black/20 text-xs font-medium backdrop-blur">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>{isDemo ? 'Demo Mode Active' : 'Live Cloud Firestore'}</span>
            </div>
          </div>
        </div>

        {/* Background decorative circles */}
        <div className="absolute -right-12 -bottom-12 w-64 h-64 rounded-full bg-white/5 blur-2xl pointer-events-none" />
      </div>

      {/* Quick Metrics Preview */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Chart of Accounts</span>
            <FolderTree className="w-4 h-4 text-brand-500" />
          </div>
          <p className="mt-2 text-2xl font-bold text-slate-900 dark:text-white">{accounts.length}</p>
          <p className="mt-1 text-xs text-slate-400">{activeAccounts.length} Active / {assetCount} Assets, {liabilityCount} Liab.</p>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Liabilities</span>
            <Receipt className="w-4 h-4 text-amber-500" />
          </div>
          <p className="mt-2 text-2xl font-bold text-slate-900 dark:text-white">$0.00</p>
          <p className="mt-1 text-xs text-slate-400">Balanced Equation: A = L + E</p>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Net Income</span>
            <TrendingUp className="w-4 h-4 text-emerald-500" />
          </div>
          <p className="mt-2 text-2xl font-bold text-slate-900 dark:text-white">$0.00</p>
          <p className="mt-1 text-xs text-slate-400">Revenue - Expenses</p>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Journal Entries</span>
            <Layers className="w-4 h-4 text-purple-500" />
          </div>
          <p className="mt-2 text-2xl font-bold text-slate-900 dark:text-white">0 Posted</p>
          <p className="mt-1 text-xs text-slate-400">Stage 3 Double-Entry Engine</p>
        </div>
      </div>

      {/* Stage Roadmap Progress Card */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Application Build Pipeline
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Structured progressive rollout across 7 stages
            </p>
          </div>
          <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
            Stage 2 Completed
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
          {stageFeatures.map((f, i) => (
            <div
              key={i}
              className={`p-4 rounded-2xl border transition-all ${
                f.status === 'completed'
                  ? 'border-emerald-200 dark:border-emerald-800/60 bg-emerald-50/30 dark:bg-emerald-950/20'
                  : f.status === 'up-next'
                  ? 'border-brand-200 dark:border-brand-800 bg-brand-50/20 dark:bg-brand-950/20 ring-1 ring-brand-400/40'
                  : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-900 dark:text-white">
                  {f.title}
                </span>
                <span
                  className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${
                    f.status === 'completed'
                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200'
                      : f.status === 'up-next'
                      ? 'bg-brand-100 text-brand-800 dark:bg-brand-900 dark:text-brand-200'
                      : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                  }`}
                >
                  {f.badge}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                {f.description}
              </p>
              {f.link && (
                <Link
                  to={f.link}
                  className="mt-3 inline-flex items-center space-x-1 text-xs font-semibold text-brand-600 dark:text-brand-400 hover:underline"
                >
                  <span>Open Page</span>
                  <ArrowRight className="w-3 h-3" />
                </Link>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
